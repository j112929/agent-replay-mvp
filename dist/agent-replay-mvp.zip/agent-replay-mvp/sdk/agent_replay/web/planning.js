import {esc,pretty} from './v2.js';

export function renderPlanning(trace){
  const sessions=trace?.metadata?.planning?.sessions;
  if(!Array.isArray(sessions)||!sessions.length)return '';
  return `<section class="panel section-space"><div class="panel-head"><h2>Predictive planning decisions</h2><span class="badge">Hypotheses ≠ real observations</span></div><div class="panel-body"><label>Prediction error filter<select data-planning-filter><option value="all">All decisions</option><option value="errors">Prediction mismatches</option><option value="denied">Denied / failed planning</option></select></label>${sessions.map((s,index)=>{
    const outcomes=s.outcomes||[],selection=s.selection||{};
    const errors=outcomes.some(o=>!o.outcome_match),denied=['failed','execution_denied','execution_error'].includes(s.status);
    const rollout=(s.rollouts||[]).find(r=>r.candidate_id===selection.selected_candidate_id);
    return `<details id="planning-${esc(s.session_id)}" data-planning-decision data-error="${errors}" data-denied="${denied}"><summary>Decision ${index+1} · ${esc(selection.selected_action?.tool_name||s.status)} · ${errors?'prediction mismatch':s.status==='selected'?'compared':'unavailable'}</summary><p class="help">State version ${esc(s.origin?.state_version)} · ${esc(s.world_model?.id)} / ${esc(s.world_model?.version)} · ${Math.round(s.planning_latency_ms||0)} ms · ${esc(s.budget?.tokens)} tokens · ${esc(selection.calibration_status||'unavailable')}</p><p>${esc(selection.selection_reason||s.reason||'No selection')}</p><div class="table-scroll"><table><thead><tr><th>Candidate</th><th>Score</th><th>Failure risk</th><th>Selected</th></tr></thead><tbody>${(s.candidates||[]).map(c=>{const score=(selection.alternative_candidates||[]).find(x=>x.candidate_id===c.candidate_id);return `<tr><td>${esc(c.tool_name)}<small>${esc(pretty(c.action_payload))}</small></td><td>${esc(score?.score?.toFixed(4)??'unknown')}</td><td>${esc(score?.risk?.toFixed(3)??'unknown')}</td><td>${c.candidate_id===selection.selected_candidate_id?'✓':'—'}</td></tr>`;}).join('')}</tbody></table></div><div class="grid2"><div><h4>Predicted first observation</h4><pre class="result-detail">${esc(pretty(rollout?.simulated_steps?.[0]?.prediction?.outcomes??null))}</pre></div><div><h4>Actual observation</h4><pre class="result-detail">${esc(pretty(s.real_execution?.actual_observation??null))}</pre></div></div><h4>Prediction errors</h4><pre class="result-detail">${esc(pretty(outcomes))}</pre><details><summary>All imagined futures, uncertainty and provenance</summary><pre class="result-detail">${esc(pretty({origin:s.origin,rollouts:s.rollouts,scores:s.scores,configuration:s.planning_config,budget:s.budget}))}</pre></details><p class="help">Only the selected first action may reach the caller’s authorized executor. Imagined steps never invoke real tools. Numeric confidence is not evidence of calibration.</p></details>`;
  }).join('')}</div></section>`;
}
if(typeof document!=='undefined')document.addEventListener('change',event=>{
  if(!event.target.matches('[data-planning-filter]'))return;
  const filter=event.target.value;
  event.target.closest('section').querySelectorAll('[data-planning-decision]').forEach(row=>row.hidden=filter==='errors'&&row.dataset.error!=='true'||filter==='denied'&&row.dataset.denied!=='true');
});
