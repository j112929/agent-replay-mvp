#!/usr/bin/env python3
"""Thin entrypoint for the self-contained Agent Regression Debugger SDK."""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'vendor'))
from agent_replay.cli import main
if __name__=='__main__':raise SystemExit(main())
