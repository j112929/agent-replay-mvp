"""Render only aggregate refund evidence; never copy trajectory or ZIP artifacts."""
import argparse
from collections import defaultdict
import html
import json
from pathlib import Path

from agent_replay.experience.collection import held_out, validate_collection

LABELS = {
    'approval-cap': '批准金额上限', 'remaining-balance': '剩余支付余额',
    'request-cap': '请求金额上限', 'prior-partial-refund': '已有部分退款',
    'near-exhausted': '余额接近耗尽', 'small-approval': '小额批准',
    'large-payment': '大额支付', 'exact-remaining': '恰好剩余金额',
    'request-after-refund': '退款后的新请求', 'low-remaining': '低剩余余额',
    'approval-after-refund': '退款后的批准上限', 'small-request': '小额请求',
}


def render(dataset, model_experiments=None, language="zh"):
    if language not in ("zh", "en"):
        raise ValueError("Unsupported report language")
    data = validate_collection(dataset)
    evaluation = held_out(dataset)
    families = defaultdict(list)
    for row in data['records']:
        families[row['family_id']].append(row)
    family_rows = []
    for family, records in sorted(families.items()):
        splits = {r['split'] for r in records}
        if len(splits) != 1:
            raise ValueError('Task family crosses dataset splits')
        name = LABELS.get(family.removeprefix('refund/'), family)
        scenarios = len({r['scenario_digest'] for r in records})
        family_rows.append(f'<tr><th scope="row">{html.escape(name)}</th><td><span class="split-tag">{next(iter(splits))}</span></td><td>{scenarios}</td><td>{len(records)}</td><td>{scenarios}/{scenarios} 已通过</td></tr>')
    split_cards = []
    for split in ('train', 'validation', 'test'):
        records = [r for r in data['records'] if r['split'] == split]
        split_cards.append(f'<article class="split-card"><h3>{split}</h3><strong>{len(records)} <small>条记录</small></strong><p>{len({r["family_id"] for r in records})} 个家族 · {len({r["scenario_digest"] for r in records})} 个场景</p></article>')
    metric_rows = []
    for split, value in sorted(evaluation['splits'].items()):
        baseline, candidate = [value['candidates'][key] for key in ('broken', 'fixed')]
        cell = lambda m: f'{m["numerator"]}/{m["denominator"]} <span class="muted">({m["value"]:.0%})</span>'
        metric_rows.append(f'<tr><th scope="row">{split}</th><td>{cell(baseline)}</td><td>{cell(candidate)}</td><td>+{value["success_rate_delta"]*100:.0f} 个百分点</td></tr>')
    model_status = '<section class="measurement-status" aria-labelledby="model-status"><span class="status-pill">尚未完成 · 未测量</span><h2 id="model-status">跨模型实测尚未完成</h2><p>等待至少两个真实模型及 provider 配置。离线接口测试不计入跨模型复现指标；未测量不等于 0%。</p></section>'
    model_panel = ''
    measured = False
    if model_experiments is not None:
        from agent_replay.experience.models import evaluate_models
        evidence = evaluate_models(dataset, model_experiments)
        # Always recompute from source-bound execution evidence. Never publish raw traces.
        if evidence['scope'] != 'live':
            raise ValueError('Offline wire tests cannot be published as real model measurements')
        reproduction = evidence['cross_model_failure_reproduction']
        counts = evidence['verdict_counts']
        coverage = evidence['coverage']
        measured = reproduction['state'] == 'measured'
        complete = measured and coverage['decisive_runs'] == coverage['planned_runs']
        status = '实测完成' if complete else '实测尚未完成'
        failure_note = ''
        report = json.loads((Path(model_experiments) / 'report.json').read_text())
        quota_errors = 0
        format_errors = 0
        for run in report['runs']:
            experiment = json.loads((Path(model_experiments) / run['experiment_path']).read_text())
            error = ((experiment.get('trace') or {}).get('execution') or {}).get('error') or {}
            if error.get('type') == 'JSONDecodeError':
                format_errors += 1
            if error.get('type') == 'ProviderError' and 'credit_balance_exhausted' in error.get('message', ''):
                quota_errors += 1
        if quota_errors:
            failure_note = f'其中 {quota_errors} 次因 OpenAI API 余额耗尽被拒绝，需补充额度后重新评估。错误不代表模型任务失败。'

        model_status = f'<section class="measurement-status" aria-labelledby="model-status"><span class="status-pill">{status}</span><h2 id="model-status">跨模型真实调用评估</h2><p>OpenAI 固定版本模型 · 仅 validation / test · {coverage["planned_runs"]} 次计划执行，{coverage["decisive_runs"]} 次取得业务判定。成功 {counts["pass"]}，失败 {counts["fail"]}，调用错误 {counts["error"]}，无法判定 {counts["inconclusive"]}。{failure_note}</p></section>'
        rows = []
        for split, models in evidence['held_out'].items():
            for model in models:
                rate = '未测量' if model['success_rate'] is None else f'{model["success_rate"]:.1%}'
                rows.append(f'<tr><th scope="row">{html.escape(model["model"])}</th><td>{split}</td><td>{model["successes"]}/{model["decisive"]} ({rate})</td><td>{model["decisive"]}/{model["planned"]}</td></tr>')
        format_note = f'本轮有 {format_errors} 次原始 JSON 解析失败，计入端到端任务失败。评估要求直接输出 JSON，未启用 JSON 强制格式，也未自动剥离 Markdown 代码围栏；因此这些失败不能单独解释为退款金额判断错误。' if format_errors else ''
        value = '未测量' if reproduction['value'] is None else f'{reproduction["value"]:.1%}'
        model_panel = f'<section class="panel" aria-labelledby="real-model-heading"><div class="panel-head"><h2 id="real-model-heading">真实模型 Held-out 评估</h2><span class="muted">固定版本 · 按计划重复执行</span></div><div class="table-scroll"><table><thead><tr><th scope="col">模型</th><th scope="col">划分</th><th scope="col">成功 / 可判定执行</th><th scope="col">可判定 / 计划执行</th></tr></thead><tbody>{"".join(rows)}</tbody></table></div><div class="panel-note"><p>跨模型失败复现：{reproduction["numerator"]}/{reproduction["denominator"]} ({value})。分母为两个模型所有重复执行均可判定的共同场景；分子要求至少两个模型的所有重复执行均失败。没有共同失败不代表没有其他失败模式。</p><p>成功率按执行次数计算，调用错误与无法判定不计为业务失败。{format_note}每个划分仅 2 个合成场景，不能推断生产泛化能力或 RL 训练收益。场景来源、verifier 资格和真实调用响应已在本地重新核验，公开页面仅含汇总指标。</p></div></section>'
    scenario_count = len({r['scenario_digest'] for r in data['records']})
    content = f'''<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="description" content="Refund 合成任务家族、无泄漏数据划分和 held-out 规则候选评估。真实模型评估状态与指标。"><title>Replay — Refund evaluation</title><link rel="stylesheet" href="/dashboard.css"><link rel="stylesheet" href="/rollout.css"><link rel="stylesheet" href="/refund/summary.css"><link rel="stylesheet" href="/navigation.css"></head>
<body><div class="shell"><aside class="sidebar"><a class="brand" href="/"><span class="brand-mark">↳</span> replay <span class="version">0.4</span></a><div class="nav-group-label">工作台</div><nav class="nav site-navigation" aria-label="主站导航"><a href="/"><span class="nav-icon" aria-hidden="true">◈</span><span>总览</span></a><a href="/debugger.html"><span class="nav-icon" aria-hidden="true">⇄</span><span>回放与回归</span></a><a href="/benchmark.html"><span class="nav-icon" aria-hidden="true">◷</span><span>基准测试</span></a><div class="nav-group-label">评估报告</div><a class="active" aria-current="page" href="/refund/evaluation.html"><span class="nav-icon" aria-hidden="true">✓</span><span>Refund 评估</span></a></nav><div class="sidebar-footer"><p>汇总指标公开展示。<br>源码与数据集 ZIP 保留本地。</p></div></aside>
<main class="main"><div class="topbar"><span>评估报告 &nbsp; / &nbsp; <strong>Refund</strong></span><nav class="language-switch" aria-label="Language"><a href="/refund/evaluation.html" lang="zh-CN" data-language="zh">中文</a><a href="/refund/evaluation-en.html" lang="en" data-language="en">English</a></nav></div><div class="workspace">
<header class="page-head"><div><div class="eyebrow">REFUND · HELD-OUT EVALUATION</div><h1>Refund 评估汇总</h1><p>从独立任务家族到数据划分，再到验证集与测试集的实际执行结果。</p></div><span class="badge synthetic">SYNTHETIC · {'LIVE MODELS' if measured else 'OFFLINE'}</span></header>
{model_status}
{model_panel}
<div class="metrics"><div class="metric"><span>独立任务家族</span><strong>{len(families)}</strong><small>分别采集的合成策略任务</small></div><div class="metric"><span>可执行场景</span><strong>{scenario_count}</strong><small>每个家族含 2 个变异场景</small></div><div class="metric"><span>已取得资格的 verifier</span><strong>{scenario_count}/{scenario_count}</strong><small>正例 + 7 类反例验证</small></div><div class="metric"><span>带 reward 的记录</span><strong>{len(data['records'])}</strong><small>执行记录数，与场景数分别统计</small></div></div>
<section aria-labelledby="split-heading"><div class="section-heading"><h2 id="split-heading">数据划分</h2><span class="badge pass">validation / test 均非空</span></div><div class="split-grid">{''.join(split_cards)}</div><p class="section-note">按来源轨迹、任务家族、父失败与等价任务整体分组。相关场景保持在同一划分；没有通过拆分兄弟场景填充 validation 或 test。</p></section>
<section class="panel" aria-labelledby="heldout-heading"><div class="panel-head"><h2 id="heldout-heading">Held-out 评估</h2><span class="muted">仅 validation / test · 同一场景配对比较</span></div><div class="table-scroll"><table><caption class="sr-only">规则候选成功数 / 场景数；比例分母为场景，不是执行记录</caption><thead><tr><th scope="col">划分</th><th scope="col">Broken 成功 / 场景数</th><th scope="col">Fixed 成功 / 场景数</th><th scope="col">成功率变化</th></tr></thead><tbody>{''.join(metric_rows)}</tbody></table></div><div class="panel-note"><p>每个场景只有在该候选的所有重复执行均通过时才记为成功。validation 与 test 各含 2 个场景，样本量有限。</p><p><strong>这是合成环境中的规则候选对比。</strong>未进行 RL 训练，不能将上述变化解释为训练收益或真实模型能力提升。</p></div></section>
<section class="panel families" aria-labelledby="families-heading"><div class="panel-head"><h2 id="families-heading">任务家族</h2><span class="muted">变异：措辞调整 / 临时查询故障</span></div><div class="table-scroll"><table><caption class="sr-only">每个任务家族的数据划分、场景数、记录数和 verifier 资格状态</caption><thead><tr><th scope="col">家族</th><th scope="col">划分</th><th scope="col">场景</th><th scope="col">记录</th><th scope="col">Verifier 资格</th></tr></thead><tbody>{''.join(family_rows)}</tbody></table></div></section>
<div class="footer"><span>Failure → Mutation → Qualified verifier → Held-out evaluation</span><span>本页仅提供汇总。源码和完整数据集 ZIP 保留本地。</span></div></div></main></div></body></html>'''
    if language == "en":
        try:
            from refund_translations import english
        except ModuleNotFoundError:
            from scripts.refund_translations import english
        content = english(content)
    active = "en" if language == "en" else "zh"
    content = content.replace(f'data-language="{active}"', f'data-language="{active}" aria-current="true"')
    return content.replace("</body>", '<script type="module" src="/refund/language.js"></script></body>')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('dataset'); parser.add_argument('output')
    parser.add_argument('--language', choices=('zh', 'en'), default='zh')
    parser.add_argument('--model-experiments', help='Reverify local real-model execution evidence')
    args = parser.parse_args()
    destination = Path(args.output).resolve()
    if destination.is_relative_to(Path(args.dataset).resolve()):
        raise ValueError('Report must be outside immutable dataset')
    content = render(args.dataset, args.model_experiments, args.language)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(content, encoding='utf-8')


if __name__ == '__main__': main()
